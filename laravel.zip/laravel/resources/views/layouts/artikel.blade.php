<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="container">
	<div class="row">
		<div class="MultiCarousel" data-items="1,3,3,3" data-slide="2" id="MultiCarousel"  data-interval="1000">
            <div class="MultiCarousel-inner">
                <div class="item h-50">
                    <div class="pad15">
                        <div class="row">
                            <div class="col-4 ">
                                &nbsp;
                            </div>
                        </div>
                        <div class="row">
                            <h1><b>Apa yang membuat beras merah<br>lebih rendah karbohidrat?</b></h1>
                        </div>
                    </div>
                </div>
                <div class="item h-50">
                    <div class="pad15">
                        <div class="row">
                            <div class="col-4 bg-dark">

                            </div>
                        </div>
                        <div class="row">
                            <h1><b>Apa yang membuat beras merah<br>lebih rendah karbohidrat?</b></h1>
                        </div>
                    </div>
                </div>
                <div class="item h-50">
                    <div class="pad15">
                        <div class="row">
                            <div class="col-4 bg-dark">

                            </div>
                        </div>
                        <div class="row">
                            <h1><b>Apa yang membuat beras merah<br>lebih rendah karbohidrat?</b></h1>
                        </div>
                    </div>
                </div>
                <div class="item h-50">
                    <div class="pad15">
                        <div class="row">
                            <div class="col-4 bg-dark">

                            </div>
                        </div>
                        <div class="row">
                            <h1><b>Apa yang membuat beras merah<br>lebih rendah karbohidrat?</b></h1>
                        </div>
                    </div>
                </div>
                <div class="item h-50">
                    <div class="pad15">
                        <div class="row">
                            <div class="col-4 bg-dark">

                            </div>
                        </div>
                        <div class="row">
                            <h1><b>Apa yang membuat beras merah<br>lebih rendah karbohidrat?</b></h1>
                        </div>
                    </div>
                </div>
            </div>
            <button class="btn btn-primary leftLst"><</button>
            <button class="btn btn-primary rightLst">></button>
        </div>
	</div>
	<div class="row">
	    <div class="col-md-12 text-center">
	        <br/><br/><br/>
	        <hr/>
	        <p>Settings</p>
	        <p>Change data items for xs,sm,md and lg display items respectively. Ex:data-items="1,3,5,6"</p>
	        <p>Change data slide for slides per click Ex:data-slide="1"</p>
	    </div>
	</div>
</div>