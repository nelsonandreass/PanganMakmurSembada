<div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(255, 255, 255);"></div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 mx-auto mbr-form" data-form-type="formoid">
                <form action="https://mobirise.eu/" method="POST" class="mbr-form form-with-styler" data-form-title="Form Name"><input type="hidden" name="email" data-form-email="true" value="JQZUOeh+vVArIdeS3UyT/znMHn1+rRqz1jkPrWHXIMJ1mL2U9SeDNo4HrC+LnRa2ikfPcr8WSTE/TC+y8VQuD3Sy3xutHKoY3r5GG26yjaFBI+LksB20d83dtJ7vu/10">
                    <div class="row">
                        <div hidden="hidden" data-form-alert="" class="alert alert-success col-12">Thanks for filling out the form!</div>
                        <div hidden="hidden" data-form-alert-danger="" class="alert alert-danger col-12">
                            Oops...! some problem!
                        </div>
                    </div>
                    <div class="dragArea row">
                        <div class="col-12">
                            <h1 class="mbr-section-title mb-4 mbr-fonts-style align-center display-2">
                                <strong>Get Latest Updates!</strong>
                            </h1>
                        </div>
                        <div class="col-12">
                            <p class="mbr-text mbr-fonts-style mb-5 align-center display-7">Start with creating a new website and picking up the theme. Then expand the blocks panel with the big red "plus" button in the lower right corner and start dragging the blocks you like.</p>
                        </div>
                        <div class="col-md col-12 form-group mb-3" data-for="name">
                            <input type="text" name="name" placeholder="Name" data-form-field="Name" class="form-control" id="name-form1-o">
                        </div>
                        <div class="col-md col-12 form-group mb-3" data-for="email">
                            <input type="email" name="email" placeholder="Email" data-form-field="Email" class="form-control" id="email-form1-o">
                        </div>
                        <div class="mbr-section-btn col-12 col-md-auto">
                            <button type="submit" class="btn btn-primary display-4">Subscribe</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>