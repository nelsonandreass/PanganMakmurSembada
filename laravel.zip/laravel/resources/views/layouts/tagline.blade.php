<div class="section w-100 tagline m-0 p-0" style="max-width:100% !important">
    <div class="d-none d-md-block overlay" >
        <div class="container-fluid" style="height:50vh;padding-left:10%">
            <div class="row h-100">
                <div class="my-auto">
                    <div class="row">
                        <div class="col-md-6" >
                            <h1 class="bold" style="color:white">"Menyediakan<br>produk kualitas<br>terbaik, hanya<br>untuk anda."</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
