<div class="section w-100 background-light-dark d-block d-md-none"  id="whymobile">
    <!-- <div class="container-fluid ">
        <div class="row p-0 m-0" >
            <div class="row ">
                <div class="col-md-12 my-auto">
                    <h2 class="text-center"><b>Mengapa Memilih Kami</b></h2> 
                </div>
            </div>
            <div class="row justify-content-center text-green p-0 m-0" >
                <div class="col-md  mb-2 card mx-2 text-center p-3 h-50">
                    <div class="row">
                        <img src="" alt="image" class="w-100 h-50">
                    </div>
                    <div class="row h-50">
                    <h2><b>Rice Expert</b></h2>
                    </div>
                    <div class="row ">
                        <p>Dengan pengalaman lebih dari <b>30 tahun</b> dalam dunia beras, menjadikan kami lebih<b>terpercaya dan berpengalaman</b></p>
                    </div>
                </div>
                <div class="col-md  mb-2 card mx-2 text-center p-3 h-50">
                    <div class="row">
                        <img src="" alt="image" class="w-100 h-70">
                    </div>
                    <div class="row h-50">
                        <h2><b>Reliable Supplier</b></h2>
                    </div>
                    <div class="row">
                        <p>Rekan kerja yang <b>terpercaya dan dapat diandalkan</b>. Bersama mewujudkan impian anda.</p>
                    </div>
                </div>
                <div class="col-md  mb-2 card mx-2 text-center p-3 h-50">
                    <div class="row">
                        <img src="" alt="image" class="w-100 h-50">
                    </div>
                    <div class="row h-50">
                        <h2><b>Fair Price <br>Top Quality</b></h2>
                    </div>
                    <p> Pemilihan bahan baku terbaik, untuk menghasilkan beras dengan <b>kualitas dan harga terbaik</b></p>

                </div>
                <div class="col-md  mb-2 card mx-2 text-center p-3 h-50">
                    <div class="row">
                        <img src="" alt="image" class="w-100 h-50">
                    </div>
                    <div class="row h-50">
                        <h2><b>The Best<br>Service</b></h2>
                    </div>
                    <p>Pelayanan, pengalaman dan rekan kerja terbaik untuk anda.<b>Your Satisfaction Is Our Priority</b></p>

                </div>
                <div class="col-md  mb-2 card mx-2 text-center p-3 h-50">
                    <div class="row">
                        <img src="" alt="image" class="w-100 h-50">
                    </div>
                    <div class="row h-50">
                        <h2><b>Wide<br>Distribution</b></h2>
                    </div>
                    <p>Melayani pengiriman untuk <b>seluruh Indonesia</b></p>
                </div>
            </div>
        </div>
    </div> -->
</div>