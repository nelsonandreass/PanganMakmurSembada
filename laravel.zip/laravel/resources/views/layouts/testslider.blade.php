<div class="section w-100" style="height:120vh;" id="produk">
    <div class="container-fluid h-100">
        <div class="row h-100">
            <div class="wrapper my-auto">
                <h1 class="text-center row mt-auto mb-5"><b>Produk Kami</b></h1>
                <div class="product-slider my-auto mx-auto" style="width:80%" >
                    @foreach($products as $product)
                    <div class="items bg-dark m-2 card" style="height:30vh;">test</div>
                    @endforeach
                    <div class="items bg-dark m-2 card" style="height:30vh;">test</div>

                </div>
            </div>
        </div>
    </div>
</div>