<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

use App\Models\Gallery;
use App\Models\Store;



class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function mobirise(){
        return view('mobirise');
    }


    public function index(){
        // banner
        $banners = Gallery::where("category" , "=" , "Banner")->get();
        $first_banner = $banners[0];
        unset($banners[0]);
       
        // end of banner

        // mini gallery
        $mini_galleries = Gallery::where("category" , "=" , "MiniGallery")->take(8)->get();
        //dd($mini_galleries);
        //end of mini gallery

        // product
        $products = Gallery::where("category" , "=" , "Product")->get();
        
        // end of product

        //store
        $stores = Store::get();
        //end of store

        return view('lending' , ['banners' => $banners , 'first_banner' => $first_banner , "minigalleries" => $mini_galleries , 'products' => $products, 'stores' => $stores]);
    }
    
}
