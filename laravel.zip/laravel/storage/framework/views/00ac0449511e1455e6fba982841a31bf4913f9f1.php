<div class="section w-100 profile" id="profile">
    <div class="container-fluid p-0 m-0 d-none d-md-block">
        <div class="row " style="height:100vh !important;margin-left:10%;margin-right:10%;">
            <div class="col-md-6 my-auto ">
                <div class="wrapper text-center">
                    <img src="<?php echo e(url('/assets/images/pexels-pixabay-164504.jpg')); ?>" class="img-desc">
                </div>
            </div> 
            <div class="col-md-6 my-auto px-5">
                <h1 class="bold text-wrap"><b>PT. Pangan<br>Makmur Sembada</b></h1>
                <div class="row">&nbsp;</div>
                <p class="text-wrap">Merupakan perusahaan yang bergerak dibidang produksi & distribusi beras yang bertempat di Jakarta Dengan pengalaman lebih dari 30 tahun dalam dunia komoditi pangan. kami PT. Pangan Makmur Sembada selalu berusaha memberikan produk beras terbaik ke tangan para konsumen</p>
            </div>
        </div>
    </div>

    <div class="container p-0 m-0 d-block d-sm-none">
        <div class="row p-0 m-0" style="height:100vh !important;">
            <div class="col-md-6 my-3">
                <img src="<?php echo e(url('/assets/images/pexels-pixabay-164504.jpg')); ?>" class="img-desc-mobile">

            </div>
            <div class="col-md-6 my-3 px-5 ">
                <h1 class="bold text-wrap"><b>PT. Pangan<br>Makmur Sembada</b></h1>
                <div class="row">&nbsp;</div>
                <p class="text-wrap">Merupakan perusahaan yang bergerak dibidang <br> produksi & distribusi beras yang bertempat di Jakarta<br>Dengan pengalaman lebih dari 30 tahun dalam dunia <br> komoditi pangan. kami PT. Pangan Makmur Sembada<br>selalu berusaha memberikan produk beras terbaik ke <br>tangan para konsumen</p>
            </div>
        </div>
    </div>
</div>

<!-- <div class="row h-100 " id="profile" style="height:100vh !important;">
    <div class="col-md-6 my-auto text-end container" >
        <img src="<?php echo e(url('/storage/'.$first_banner->foto)); ?>" class="img-size-accent" style="heigth:50vh;width:50vh"  alt="...">
    </div>
    <div class="col-md-6 my-auto container pr-5">
        <h1><b>PT. Pangan<br>Makmur Sembada</b></h1>
        <div class="row">&nbsp;</div>
        <p class="text-wrap">Merupakan perusahaan yang bergerak dibidang <br> produksi & distribusi beras yang bertempat di Jakarta</p>
        <div class="row">&nbsp;</div>
        <p class="text-wrap">Dengan pengalaman lebih dari 30 tahun dalam dunia <br> komoditi pangan. kami PT. Pangan Makmur Sembada<br>selalu berusaha memberikan produk beras terbaik ke <br>tangan para konsumen</p>
    </div>
</div> --><?php /**PATH D:\companyprofile\resources\views/layouts/desc.blade.php ENDPATH**/ ?>