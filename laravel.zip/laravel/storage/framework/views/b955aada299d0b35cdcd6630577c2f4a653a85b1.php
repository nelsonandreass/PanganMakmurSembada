<div class="section w-100" style="height:120vh;" id="produk">
    <div class="container-fluid h-100">
        <div class="row h-100">
            <div class="wrapper my-auto">
                <h1 class="text-center row mt-auto mb-5"><b>Produk Kami</b></h1>
                <input type="hidden" id="tempid">
                <div class="center my-auto mx-auto" style="width:80%" >
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item px-3" style="" id="<?php echo e($product->foto); ?>">
                        <div class="row mb-3">
                            <div class="col-12 h-75">
                                <img src="<?php echo e(url('/storage/'.$product->foto)); ?>" class="w-100" style="border-radius:.5rem;"  alt="...">
                            </div>
                        </div>
                        <?php
                            $id = "desc-".substr($product->foto,0,strlen($product->foto)-4)
                        ?>
                        <div class="row mb-3 d-none" id="<?php echo e($id); ?>">
                            <h6 class="text-green text-center"><?php echo e($product->nama); ?></h6>
                            <br>
                            <pre class="text-wrap text-center"><?php echo e($product->jenis); ?></pre>
                            <br>
                            <pre class="text-wrap text-center font-bold"><b>Tersedia dalam ukuran</b></pre>
                            <pre class="text-center"><?php echo e($product->ukuran); ?></pre>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\companyprofile\resources\views/layouts/carouselproduct.blade.php ENDPATH**/ ?>