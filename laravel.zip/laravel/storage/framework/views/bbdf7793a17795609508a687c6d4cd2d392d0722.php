<div class="section ml-auto fixed-bottom">
	<div class="row">
		<a href="https://wa.me/message/O63XN3LZYRLJC1" target="_blank"><img src="<?php echo e(url('/assets/images/wa.png')); ?>" class="ml-auto m-4" style="float:right;width:3rem;height:3rem;"></a>
	</div>
	<div class="row">
		
	</div>
</div><?php /**PATH D:\companyprofile\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>