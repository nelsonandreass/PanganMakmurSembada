<div class="section w-100 d-none d-md-block" style="height:auto !important;" id="gallery">
    <div class="row w-100 m-0 p-0" >
        <?php $__currentLoopData = $minigalleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 m-0 p-0">
                <img src="<?php echo e(url('/storage/'.$gallery->foto)); ?>" class="d-block" style="width:100%" >
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\companyprofile\resources\views/layouts/minigallery.blade.php ENDPATH**/ ?>